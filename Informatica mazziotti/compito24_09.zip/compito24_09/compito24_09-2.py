import os
from dataclasses import dataclass
import pickle

os.chdir(os.path.dirname(os.path.abspath(__file__)))

@dataclass
class StudentePagante:
    nome: str
    cognome: str
    eta: int
    prezzo: float

try:
    classe_richiesta = input("Inserire la classe per la quale generare la comunicazione: ").strip().upper()
    nome_file_pkl = f"biglietti_{classe_richiesta}.pkl"
    nome_file_txt = f"comunicazione_{classe_richiesta}.txt"

    with open(nome_file_pkl, "rb") as f:
        studenti = pickle.load(f)

    with open(nome_file_txt, "w") as f:
        f.write(f"COMUNICAZIONE PER LA CLASSE {classe_richiesta}\n")
        f.write("="*75 + "\n")
        
        intestazione_nome = "Nome"
        spazi_nome_int = " " * (35 - len(intestazione_nome))
        
        intestazione_cognome = "Cognome"
        spazi_cognome_int = " " * (15 - len(intestazione_cognome))
        
        intestazione_eta = "Eta"
        spazi_eta_int = " " * (10 - len(intestazione_eta))
        
        intestazione_prezzo = "Prezzo (Euro)"
        spazi_prezzo_int = " " * (10 - len(intestazione_prezzo))
        
        f.write(intestazione_nome + spazi_nome_int +
                intestazione_cognome + spazi_cognome_int +
                intestazione_eta + spazi_eta_int +
                intestazione_prezzo + spazi_prezzo_int + "\n")
        
        f.write("-"*75 + "\n")

        for s in studenti:
            nome_str = s.nome
            spazi_nome = " " * (35 - len(nome_str))
            
            cognome_str = s.cognome
            spazi_cognome = " " * (15 - len(cognome_str))
            
            eta_str = str(s.eta)
            spazi_eta = " " * (10 - len(eta_str))
            
            prezzo_str = str(s.prezzo)
            spazi_prezzo = " " * (15 - len(prezzo_str))
            
            f.write(nome_str + spazi_nome +
                    cognome_str + spazi_cognome +
                    eta_str + spazi_eta +
                    prezzo_str + spazi_prezzo + "\n")
        
        f.write("-"*75 + "\n")
        
        totale = 0.0
        for s in studenti:
            totale += s.prezzo
        
        totale_str = str(totale)
        f.write(f"TOTALE DA PAGARE: Euro {totale_str}\n")

    print(f"File {nome_file_txt} creato con successo.")

except FileNotFoundError as e:
    print(f"Errore: File {nome_file_pkl} non trovato. Dettagli: {e}")
except IOError as e:
    print(f"Errore di I/O: Impossibile scrivere sul file. Dettagli: {e}")
except Exception as e:
    print(f"Si è verificato un errore inaspettato: {e}")